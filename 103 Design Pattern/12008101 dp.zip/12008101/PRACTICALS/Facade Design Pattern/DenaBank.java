public class DenaBank implements BankAccount
 {

   public void Create() 
   {
      System.out.println(" DenaBank Account Created ");
   }
}