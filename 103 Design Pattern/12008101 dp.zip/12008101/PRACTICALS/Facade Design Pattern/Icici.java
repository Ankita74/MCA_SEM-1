public class Icici implements BankAccount
 {

   public void Create() 
   {
      System.out.println(" Icici Account Created ");
   }
}