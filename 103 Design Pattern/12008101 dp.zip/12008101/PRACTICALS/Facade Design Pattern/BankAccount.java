public interface BankAccount {
   void Create();
}