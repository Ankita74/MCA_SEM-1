public class BoB implements BankAccount
 {

   public void Create() 
   {
      System.out.println(" BoB Account Created ");
   }
}