public interface ElectricityBill { 
    public double getElectricityBill();
    public void setElectricityCharge(double c);
    public void setElectricityUnit(double unt);
    public void setNoofMonth(int n);
    public String TearmCond();
    
}