public interface WaterBill { 
    public double getWaterBill();
    public void setWaterCharge(double c);
    public void setWaterLtr(double ltr);
    public void setNoofMonth(int n);
    public String TearmCond();
    
}