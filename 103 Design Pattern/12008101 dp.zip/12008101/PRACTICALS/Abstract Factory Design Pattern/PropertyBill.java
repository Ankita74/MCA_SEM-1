public interface PropertyBill { 
    public double getPropertyBill();
    public void setPropertyRant(double rant);
    public void setNoofMonth(int n);
    public String TearmCond();
    
}