public class Msg implements Interface
{
	public String message()
	{
		return "gujarat vidyapith is 100 YEAR OLD UNIVERSITY";
	}
}