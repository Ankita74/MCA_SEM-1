public interface Interface
{
	public String message();
}