public interface PropertyTextCalculation
{
	public double calculateTax(double amount , double rate , int year);
	
	
}