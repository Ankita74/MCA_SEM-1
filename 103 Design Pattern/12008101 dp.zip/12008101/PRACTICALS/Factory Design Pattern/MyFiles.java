public interface MyFiles
{
	
	public void create();
	public void save();
	
}