
public interface Iwebsite
{
	public String doConnect(String url) ;
}