
public interface LoanAccount
{
	
	public double getInterest();
	public void setRetofInterest(double r);
	public void setLoanAmount(double amt);
	public void setNoofYear(int n);
	public String TermCondition();
	
}