public interface UserInterface
{
	public String getFirstName();
	public String getLastName();
	public int getAge();
	public String getPhone();
	public String getAddress();

}